package mundo.parqueadero;

import com.mongodb.BasicDBObject;

public class Carro {

	// Atributos
	
	private String placa;
	private int horaLlegada;

	// Constructores
	public Carro(String placa, int horaLlegada) {
		this.placa = placa;
		this.horaLlegada = horaLlegada;
	}	

	// Transformo un objecto que me da MongoDB a un Objecto Java
	public Carro(BasicDBObject dBObjectCarro) {
		this.placa = dBObjectCarro.getString("Placa");
		this.horaLlegada = dBObjectCarro.getInt("Hora");

	}

	public BasicDBObject todBObjectCarro() {
		// Creamos una instancia BasicDBObject
		BasicDBObject dBObjectCarro = new BasicDBObject();
		dBObjectCarro.append("Placa", this.darPlaca());
		dBObjectCarro.append("Hora", this.darHoraLlegada());

		return dBObjectCarro;
	}

	// M�todos

	public String darPlaca() {
		return placa;
	}

	public int darHoraLlegada() {
		return horaLlegada;
	}

	//Placa del auto
	public boolean tienePlaca(String Placa) {
		boolean tienePlaca = false;
		if (placa.equalsIgnoreCase(Placa)){
			tienePlaca =true;
		}else {
			tienePlaca=false;
		}
		return tienePlaca;
	}

	public int darTiempoEnParqueadero(int HoraSalida) {
		int tiempoParqueadero = HoraSalida - horaLlegada +1;

		return tiempoParqueadero;
	}

	public void registarCarro() {
		System.out.println("Datos del carro");
		System.out.println("Placa: " + darPlaca());
		System.out.println("Hora de Llegada " +darHoraLlegada());
		
	}
}