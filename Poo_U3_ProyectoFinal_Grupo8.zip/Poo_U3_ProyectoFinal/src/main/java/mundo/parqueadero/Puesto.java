package mundo.parqueadero;

public class Puesto {

	// Atributos
	private Carro carro;
	private int numeroPuesto;

	// Constructores
	public Puesto(int Puesto) {
		carro=null;
		numeroPuesto=Puesto;
		
	}

	// M�todos
	public Carro darCarro() {
		return carro;
	}

	public boolean estaOcupado() {
		boolean ocupado = carro != null;
		return ocupado;
	}

	public void parquerCarro(Carro Carro) {
		carro = Carro;
	}

	public void sacarCarro() {
		carro= null;
	}

	public int darNumeroPuesto() {
		return numeroPuesto;				
	}

	public boolean tieneCarroConPlaca(String Placa) {

		boolean tieneCarro = true;
		if (carro ==null) {
			tieneCarro =false;

		}else if(carro.tienePlaca(Placa)){
			tieneCarro=true;

		} else {
			tieneCarro = false;
		}
		return tieneCarro;
	}
}
