package mundo.parqueadero;

import conexion.mongoDB.Conectar;

public class Parqueadero {

	// Constantes
	public static final int TAMANO=30;
	public static final int NO_HAY_PUESTO=-1;
	public static final int PARQUEADERO_CERRADO= -2;
	public static final int CARRO_NO_EXISTE=-3;
	public static final int CARR0_YA_EXISTE=-4;
	public static final int HORA_INICIAL =6;
	public static final int HORA_CIERRE =20;
	public static final int TARIFA_INICIAL=1;

	// Atributos
	private Puesto puesto[];
	private int tarifa;
	private int caja;
	private int horaActual;
	private boolean abierto;

	// Constructores
	public Parqueadero() {
		horaActual = HORA_INICIAL;
		abierto = true;
		tarifa = TARIFA_INICIAL;
		caja=0;

		puesto = new Puesto[TAMANO];
		for (int i=0; i< TAMANO; i++)
			puesto[i] = new Puesto(i);
	}


	// M�todos

	public String darPlacaCarro(int Posicion) {
		String respuesta="";
		if (estaOcupado(Posicion)) {
			respuesta = "Placa: " +puesto[Posicion].darCarro().darPlaca();
		}else {
			respuesta ="No hay un carro en esta posicion";
		}
		return respuesta;
	}

	public int entrarCarro(String Placa) {
		int resultado =0;
		if (!abierto) {

			resultado = PARQUEADERO_CERRADO;
		} else {

			int numPuestoCarro = buscarPuestoCarro(Placa.toUpperCase());
			if (numPuestoCarro != CARRO_NO_EXISTE ) {
				resultado = CARR0_YA_EXISTE;
			}

			resultado = buscarPuestoLibre();
			if(resultado != NO_HAY_PUESTO) {

				Carro carroEntrando = new Carro( Placa, horaActual);
				puesto[resultado].parquerCarro(carroEntrando);	
			}
		}
		return resultado;
	}

	public int sacarCarro(String Placa) {
		int resultado=0;
		if(!abierto) {
			resultado=PARQUEADERO_CERRADO;
		} else {
			int numPuesto =buscarPuestoCarro(Placa.toUpperCase());
			if(numPuesto ==CARRO_NO_EXISTE) {
				resultado = CARRO_NO_EXISTE;
			}else {
				Carro carro =puesto[numPuesto].darCarro();
				int nHoras = carro.darTiempoEnParqueadero(horaActual);
				int porPagar = nHoras*tarifa;
				caja = caja+porPagar;
				puesto[numPuesto].sacarCarro();
				resultado=porPagar;
			}
		}
		return resultado;
	}

	public int darMontoCaja() {
		return caja;
	}

	public int calcularPuestoLibres() {
		int puestosLibres=0;
		for(Puesto puesto : puesto) {
			if (!puesto.estaOcupado()) {
				puestosLibres = puestosLibres +1;
			}
		}
		return puestosLibres;
	}

	public void cambiarTarifa(int Tarifa) {
		tarifa=Tarifa;
	}

	private int buscarPuestoLibre() {
		int puestos=NO_HAY_PUESTO;
		for (int i=0; i<TAMANO && puestos ==NO_HAY_PUESTO; i++){
			if(!puesto [ i ].estaOcupado()) {
				puestos=i;
			}
		}
		return puestos;
	}

	private int buscarPuestoCarro(String Placa) {
		int puestos=CARRO_NO_EXISTE;
		for(int i=0; i<TAMANO && puestos == CARRO_NO_EXISTE; i++) {
			if (puesto[ i ].tieneCarroConPlaca(Placa)) {
				puestos=i;
			}
		}
		return puestos;
	}

	public void avanzarHora() {
		if (horaActual <= HORA_CIERRE) {
			horaActual =(horaActual +1);
		}
		if (horaActual == HORA_CIERRE) {
			abierto = false;
		}
	}

	public int darHoraActual() {
		return horaActual;
	}

	public boolean estaAbierto() {
		return abierto;
	}

	public int darTarifa(){   
		return tarifa;
	}

	public boolean estaOcupado(int Puesto) {
		boolean ocupado = puesto[Puesto].estaOcupado();
		return ocupado;
	}

}
