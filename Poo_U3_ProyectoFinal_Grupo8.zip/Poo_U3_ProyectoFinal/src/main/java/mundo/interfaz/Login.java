package mundo.interfaz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.ImageIcon;

public class Login extends JFrame {

	public JTextField textUsuario;
	private JLabel lblImagen;
	private JPasswordField jpassContrase�a;
	private JPanel contentPane;
	private JLabel lblNewLabel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setTitle("Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 408, 415);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.menu);
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblUsuario = new JLabel("Usuario");
		lblUsuario.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 13));
		lblUsuario.setBounds(245, 215, 73, 14);
		contentPane.add(lblUsuario);

		JLabel lblContrase�a = new JLabel("Contrase\u00F1a");
		lblContrase�a.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 13));
		lblContrase�a.setBounds(245, 271, 80, 14);
		contentPane.add(lblContrase�a);

		textUsuario = new JTextField();
		textUsuario.setBounds(224, 240, 111, 20);
		contentPane.add(textUsuario);
		textUsuario.setColumns(10);

		jpassContrase�a = new JPasswordField();
		jpassContrase�a.setBounds(224, 296, 111, 20);
		contentPane.add(jpassContrase�a);
		jpassContrase�a.setColumns(10);

		JButton btnIngresar = new JButton("Ingresar");
		btnIngresar.setBackground(SystemColor.controlHighlight);
		btnIngresar.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {

				char[] contrase�a = jpassContrase�a.getPassword();
				String contrase�aFinal = new String(contrase�a);

				if (textUsuario.getText().equals("Admi")&& contrase�aFinal.equals("123")) {
					dispose();
					JOptionPane.showMessageDialog(null, "Bienvenidos al Sistema", "INGRESASTE",JOptionPane.INFORMATION_MESSAGE);

					Principal principal =new Principal();
					principal.setVisible(true);

				} else {
					JOptionPane.showConfirmDialog(null,"Usuario o Contrase�a incorrectos", "ERROR",JOptionPane.ERROR_MESSAGE);
				}				
			}	
		});

		btnIngresar.setBounds(236, 327, 89, 23);
		contentPane.add(btnIngresar);

		lblImagen = new JLabel("");
		lblImagen.setIcon(new ImageIcon("./Imagenes/portada1.png"));
		lblImagen.setBounds(0, 0, 399, 152);
		contentPane.add(lblImagen);

		lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("./Imagenes/icono2.png"));
		lblNewLabel.setBounds(23, 208, 159, 142);
		contentPane.add(lblNewLabel);

	}
}
