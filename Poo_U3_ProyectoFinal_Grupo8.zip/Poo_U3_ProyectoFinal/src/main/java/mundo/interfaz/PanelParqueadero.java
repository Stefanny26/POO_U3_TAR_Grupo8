package mundo.interfaz;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

import conexion.mongoDB.Conectar;
import mundo.parqueadero.Carro;
import mundo.parqueadero.Parqueadero;

public class PanelParqueadero extends JPanel implements ActionListener{

	// Atributos de la Interfaz
	private JButton puestos[];
	
	// Atributos
	private Parqueadero parqueadero;
	private boolean ocupado[];
	
	// Constructores
	public PanelParqueadero( Parqueadero Parqueadero ){
        parqueadero = Parqueadero;
        inicializar( );
    }
	
	// M�todos
	private void inicializar( ) {
		Conectar conexion = new Conectar();
		conexion.conectar();
		
        setLayout( new GridLayout( 3, 10 ) );
        setBorder( new CompoundBorder( new EmptyBorder( 0, 0, 5, 0 ), new TitledBorder( "Parqueadero" ) ) );
        setPreferredSize( new Dimension( 10, 170 ) );
        puestos = new JButton[parqueadero.calcularPuestoLibres( )];
        
        ocupado = new boolean[parqueadero.calcularPuestoLibres( )];
        for( int i = 0; i < parqueadero.calcularPuestoLibres( ); i++ )
        {
            ocupado[ i ] = false;
            puestos[ i ] = new JButton( );
            puestos[ i ].setActionCommand( i + "" );
            puestos[ i ].addActionListener( this );
            puestos[ i ].setHorizontalTextPosition( JButton.CENTER );
            puestos[ i ].setVerticalTextPosition( JButton.CENTER );
            puestos[ i ].setForeground( Color.WHITE );
            add( puestos[ i ] );
        }
    }

    /**
     * Este m�todo se encarga de actualizar la representaci�n del parqueadero. <br>
     * <b>post: </b> Se actualiz� la informaci�n mostrada del parqueadero.
     */
    public void refrescarParqueadero( )
    {
        for( int i = 0; i < puestos.length; i++ )
        {
            if( parqueadero.estaOcupado( i ) )
            {
                if( !ocupado[ i ] )
                {
                    int indice = ( int ) ( Math.floor( Math.random( ) * 4 ) ) + 1;
                    puestos[ i ].setIcon( new ImageIcon( "Imagenes/carro" + indice + ".png" ) );
                    ocupado[ i ] = true;
                }
                puestos[ i ].setText( "" );
            }
            else
            {
                puestos[ i ].setIcon( new ImageIcon( "Imagenes/vacio.png" ) );
                puestos[ i ].setText( ( i + 1 ) + "" );
                ocupado[ i ] = false;
            }
        }
    }

    /**
     * Este m�todo se encarga de manejar los eventos de la clase.
     * @param pEvento Evento accionado.
     */
    public void actionPerformed( ActionEvent pEvento ){
    
        String numero = pEvento.getActionCommand( );
        int indice = Integer.parseInt( numero );
        String placa = parqueadero.darPlacaCarro( indice );
        JOptionPane.showMessageDialog( this, placa, "Placa", JOptionPane.INFORMATION_MESSAGE );
    }
	
}
