package mundo.interfaz;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PanelImagen extends JPanel{

	//Atributos
	private JLabel labImagen;
	
	//Contructor
	public PanelImagen() {
		labImagen = new JLabel();
		labImagen.setIcon(new ImageIcon("./Imagenes/icono3.png"));
		add(labImagen);
	}
}
