package mundo.interfaz;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

public class PanelInformacion extends JPanel implements ActionListener {

	// Atributos
	private Principal principal;
	
	// Atributos de la Interfaz
	private JLabel labValorCaja;
	private JLabel labVacios;
	
	// Constructores
	public PanelInformacion(Principal principal) {
		this.principal = principal;
		inicializar();
	}
	
	private void inicializar() {
		setLayout(new GridLayout(1,2));
		
		labValorCaja=new JLabel("Valor en Caja: ");
		labVacios=new JLabel("Puestos Vacios: ");
		
		setBorder(new CompoundBorder(new EmptyBorder(0,0,5,0), new TitledBorder("Informaci�n")));

        add(labValorCaja);
        add(labVacios);
	}
	
	public void actualizarDatos( int Vacios, int MontoCaja){
    
        labVacios.setText( "Puestos Vac�os: " +Vacios);
        labValorCaja.setText( "Valor en Caja: $ " +MontoCaja);
    }

	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}
