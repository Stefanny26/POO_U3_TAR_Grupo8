package mundo.interfaz;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import conexion.mongoDB.Conectar;
import mundo.parqueadero.Carro;
import mundo.parqueadero.Parqueadero;

public class Principal extends JFrame {
	// Atributos
	private Parqueadero parqueadero;

	// Componentes de la interfaz
	private PanelImagen panelImagen;
	private PanelParqueadero panelParqueadero;
	private PanelOperaciones panelOperaciones;
	private PanelInformacion panelInformacion;

	// Constructores
	public Principal() {
		setTitle( "Parqueadero" );
		setSize( 800, 700 );
		setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );

		// Crea el parqueadero con tarifa por hora de 1200
		parqueadero = new Parqueadero( );

		// Construir los paneles
		panelImagen = new PanelImagen( );
		panelParqueadero = new PanelParqueadero( parqueadero );
		panelOperaciones = new PanelOperaciones( this );
		panelOperaciones.setPreferredSize( new Dimension( 570, 100 ) );
		panelInformacion = new PanelInformacion( this );
		JPanel sur = new JPanel( );
		sur.setLayout( new BorderLayout( ) );

		// Organizar el panel principal
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(panelImagen, BorderLayout.NORTH);
		getContentPane().add(panelParqueadero, BorderLayout.CENTER);
		getContentPane().add(sur, BorderLayout.SOUTH );
		sur.add( panelOperaciones, BorderLayout.CENTER );
		sur.add( panelInformacion, BorderLayout.SOUTH );

		setLocationRelativeTo(null);
		setResizable( false );

		actualizar();
	}

	public void avanzar() {
		parqueadero.avanzarHora();
		actualizar( );
	}

	public void ingresar( ){	
		
	String placa = JOptionPane.showInputDialog( this, "Por favor digite la placa del carro que est� ingresando", "Ingresar carro", JOptionPane.QUESTION_MESSAGE );
    if( placa != null )
    {
        int puesto = parqueadero.entrarCarro( placa );
        
        
        switch( puesto )
        {
            case Parqueadero.NO_HAY_PUESTO:
                JOptionPane.showMessageDialog( this, "Lo sentimos: el parqueadero est� lleno" );
                break;
            case Parqueadero.CARR0_YA_EXISTE:
                JOptionPane.showMessageDialog( this, "Lo sentimos: ya hay un carro parqueado con la misma placa" );
                break;
            case Parqueadero.PARQUEADERO_CERRADO:
                JOptionPane.showMessageDialog( this, "Lo sentimos: el parqueadero est� cerrado" );
                break;
            default:
                JOptionPane.showMessageDialog( this, "Bienvenido:\n Su carro qued� parqueado en el puesto: " + ( puesto + 1 ) );
                break;
        }
        actualizar( );
       
    }

}


	public void salir() {
		String placa = JOptionPane.showInputDialog( this, "Por favor digite la placa del carro que est� saliendo", "Salida carro", JOptionPane.QUESTION_MESSAGE);
		if( placa != null ){

			int valor = parqueadero.sacarCarro(placa);
			switch(valor){

			case Parqueadero.PARQUEADERO_CERRADO:
				JOptionPane.showMessageDialog( this, "Lo sentimos: el parqueadero est� cerrado", "Error", JOptionPane.ERROR_MESSAGE);
				break;
			case Parqueadero.CARRO_NO_EXISTE:
				JOptionPane.showMessageDialog( this, "El carro de placa " + placa + " no est� en el parqueadero", "Error", JOptionPane.ERROR_MESSAGE);
				break;
			default:
				JOptionPane.showMessageDialog( this, "Placa: " + placa + " debe cancelar $ " + valor );
				break;
			}
			actualizar();
		}
	}

	public void actualizar(){
		panelParqueadero.refrescarParqueadero();
		panelOperaciones.cambiarHora(parqueadero.darHoraActual());
		panelOperaciones.cambiarTarifa(parqueadero.darTarifa());
		panelInformacion.actualizarDatos(parqueadero.calcularPuestoLibres(), parqueadero.darMontoCaja());

	}

	public void cambiar() {
		String tarifa = JOptionPane.showInputDialog(this, "Por favor digite la nueva tarifa", "Nueva tarifa", JOptionPane.QUESTION_MESSAGE);
		if(tarifa != null){

			try{			
				int tarifaNumero = Integer.parseInt(tarifa);

				if(tarifaNumero <= 0){				
					JOptionPane.showMessageDialog( this, "Ingrese una tarifa v�lida", "Tarifa inv�lida", JOptionPane.ERROR_MESSAGE);

				}else{				
					parqueadero.cambiarTarifa( tarifaNumero );
					panelOperaciones.cambiarTarifa( tarifaNumero );
					JOptionPane.showMessageDialog( this, "Se ha cambiado la tarifa", "Nueva tarifa", JOptionPane.INFORMATION_MESSAGE);
				}
			}catch( Exception e ){			
				JOptionPane.showMessageDialog( this, "Ingrese una tarifa v�lida", "Tarifa inv�lida", JOptionPane.ERROR_MESSAGE);
			}
		}
	}
	
	public static void main(String[] args) {
		// Creamos la instancia de la clase ConexionMongoDB para poder llamar al metodo
		// conectar
		Conectar conexion = new Conectar();
		conexion.conectar();

		Carro carro1 = new Carro("qwe",12);
		carro1.registarCarro();
		
	}
}
