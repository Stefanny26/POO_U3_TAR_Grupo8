package mundo.interfaz;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class PanelOperaciones extends JPanel implements ActionListener{
	// Constantes
	private final static String INGRESAR = "INGRESAR";
	private final static String SALIR = "SALIR";
	private final static String AVANZAR = "AVANZAR";
	private final static String CAMBIAR = "CAMBIAR";

	// Atributos
	private Principal principal;

	// Atributos de la Interfaz
	private JTextField txtHora;
	private JTextField txtTarifa;
	private JButton botonEntrar;
	private JButton botonSalir;
	private JButton botonAvanzarHora;
	private JButton botonCambiar;
	// Constructores

	public PanelOperaciones(Principal principal) {
		this.principal = principal;
		inicializar();
	}

	// M�todos
	private void inicializar() {

		setLayout( new GridLayout( 3, 2, 3, 3 ) );
		setBorder( new EmptyBorder( 5,5,5,5 ) );

		JPanel panelHora = new JPanel();
		panelHora.setLayout( new GridLayout( 1,2) );
		add(panelHora);
		panelHora.add(new JLabel("Hora actual: "));

		txtHora = new JTextField( );
		txtHora.setEditable( false );
		txtHora.setForeground( Color.BLUE );
		//txtHora.setBackground( getBackground( ) );
		//txtHora.setBorder( new TitledBorder( "Hora Actual" ) );
		panelHora.add( txtHora );

		JPanel panelTarifa = new JPanel();
		panelTarifa.setLayout( new GridLayout( 1,2) );
		add(panelTarifa);

		panelTarifa.add(new JLabel("Tarifa: "));
		txtTarifa = new JTextField( );
		txtTarifa.setEditable( false );
		txtTarifa.setForeground( Color.BLUE );
		//txtTarifa.setBackground( getBackground( ) );
		//txtTarifa.setBorder( new TitledBorder( "Tarifa" ) );
		panelTarifa.add(txtTarifa);
		
		botonAvanzarHora = new JButton( );
		botonAvanzarHora.setText( "Avanzar" );
		botonAvanzarHora.setActionCommand( AVANZAR );
		botonAvanzarHora.addActionListener( this );
		add( botonAvanzarHora );

		

		botonCambiar = new JButton();
		botonCambiar.setText("Cambiar");
		botonCambiar.setActionCommand(CAMBIAR);
		botonCambiar.addActionListener(this);
		add(botonCambiar);

		botonEntrar = new JButton();
		botonEntrar.setText("Ingresar Carro");
		botonEntrar.setActionCommand(INGRESAR);
		botonEntrar.addActionListener(this);
		add(botonEntrar);

		botonSalir = new JButton();
		botonSalir.setText("Sacar Carro");
		botonSalir.setActionCommand(SALIR);
		botonSalir.addActionListener(this);
		add(botonSalir);

	}

	public void cambiarHora( int Hora){   
		txtHora.setText(Hora + ":00");
	}

	public void cambiarTarifa(int Tarifa){   
		txtTarifa.setText("$" + Tarifa);
	}

	public void actionPerformed(ActionEvent Evento) {
		String command = Evento.getActionCommand();
		
		if( command.equals( INGRESAR)){
			principal.ingresar();
			
		}else if( command.equals (SALIR)){
			principal.salir( );
			
		}else if( command.equals(AVANZAR)){
			principal.avanzar();
			
		}else if( command.equals(CAMBIAR)){
			principal.cambiar();
		}
	}
	
}


