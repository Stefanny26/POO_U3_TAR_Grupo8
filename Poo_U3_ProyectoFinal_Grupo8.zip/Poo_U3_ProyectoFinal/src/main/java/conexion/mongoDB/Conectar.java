package conexion.mongoDB;

import java.util.ArrayList;

import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.MongoClient;

import mundo.parqueadero.Carro;

public class Conectar {

	public void conectar() {
		// Base de datos MongoDB
		ArrayList<Carro> carro = new ArrayList<Carro>();
		carro.add(new Carro("qwe",6));

		try {
			// PASO 1: Conexi�n al Server de MongoDB Pasandole el host y el puerto
			MongoClient mongoclient = new MongoClient("localhost", 27017);

			// PASO 2: Conexi�n a la base de datos
			DB db = mongoclient.getDB("Parqueadero");

			// PASO 3: Obtenemos una coleccion para trabajar con ella
			DBCollection collectionCarro = db.getCollection("Carros");
			
			
			// PASO 4: CRUD (Create-Read-Update-Delete)
			// PASO 4.1: "CREATE" -> Metemos los objetos futbolistas (o documentos en Mongo) en la coleccion Futbolista
			
			createDB2(carro, collectionCarro);
			DBCursor cursor;
			
			// PASO 4.2: "READ" -> Leemos todos los documentos de la base de datos
						readDB2(collectionCarro);
						
						// PASO FINAL: Cerrar la conexion mv
						mongoclient.close();

					} catch (Exception ex) {
						System.out.println("Exception al conectar al server de Mongo ");
					}
		}
	
//PASO 4.1: "CREATE" -> Metemos los objetos clientes (o documentos en Mongo) en
	// la coleccion Cliente
	public static void createDB2(ArrayList<Carro> Carros, DBCollection collectionCarro) {
		for (Carro carro : Carros) {
			collectionCarro.insert(carro.todBObjectCarro());
		}
	}
	
	// PASO 4.2.1: "READ" -> Leemos todos los documentos de la base de datos
	public static void readDB2(DBCollection collectionCarro) {
		int numDocumentos2 = (int) collectionCarro.getCount();
		System.out.println("");
		System.out.println("Numero de documentos en la coleccion Carros: " + numDocumentos2 + "\n");
		DBCursor cursor2 = collectionCarro.find();
		try {
			while (cursor2.hasNext()) {
				System.out.println(cursor2.next().toString());
			}
		} catch (Exception e) {
			System.out.println("Error al recorrer la coleccion ");
		} finally {
			cursor2.close();
		}
	}
}