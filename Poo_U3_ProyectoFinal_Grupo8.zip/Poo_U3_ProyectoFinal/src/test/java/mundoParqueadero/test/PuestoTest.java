package mundoParqueadero.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import mundo.parqueadero.Carro;
import mundo.parqueadero.Puesto;

public class PuestoTest {
	// Atributos}
	private Puesto puesto1;
	private Puesto puesto2;
	private Carro carro1;
	private Carro carro2;
	
	// M�todos
	private void setupEscenario1( ){    
        carro1 = new Carro( "aaa111", 6 );
        puesto1 = new Puesto( 1 );
    }
	
	private void setupEscenario2(){    
        carro2 = new Carro( "bbb222", 6 );
        puesto2 = new Puesto(2);
        puesto2.parquerCarro(carro2);
    }
	
	@Test
    public void testDarNumeroPuesto( ){    
        setupEscenario1( );

        assertEquals( "El n�mero retornado es incorrecto", 1, puesto1.darNumeroPuesto( ) );
    }
	
	 @Test
	    public void testEstaOcupado( ){	    
	        setupEscenario1( );
	        setupEscenario2( );

	        assertFalse( "El puesto 1 deber�a estar desocupado", puesto1.estaOcupado( ) );
	        assertTrue( "El puesto 2 deber�a estar ocupado", puesto2.estaOcupado( ) );
	    }
	
	 @Test
	    public void testSacarCarro( ){	    
	        setupEscenario2( );

	        assertTrue( "El puesto 2 no retorn� el carro que se esperaba", carro2 == puesto2.darCarro( ) );
	        puesto2.sacarCarro( );
	        assertNull( "El puesto 2 deber�a estar vac�o pero darCarro no retorn� null", puesto2.darCarro( ) );
	        assertFalse( "El puesto 2 deber�a estar desocupado", puesto2.estaOcupado( ) );
	    }
}
