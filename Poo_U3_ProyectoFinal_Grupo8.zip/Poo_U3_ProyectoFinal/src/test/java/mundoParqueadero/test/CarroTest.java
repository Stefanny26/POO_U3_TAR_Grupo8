package mundoParqueadero.test;
import static org.junit.Assert.*;
import org.junit.Test;
import mundo.parqueadero.Carro;

public class CarroTest {

	// Atributos
	private Carro carro;
	
	//Metodos
	public void setupEscenario1() {
		carro=new Carro ("abc",12);
	}
	@Test
	public void testDatos() {
		setupEscenario1( );

        String placa = carro.darPlaca( );
        int hora = carro.darHoraLlegada( );
        assertEquals( "La hora de llegada retornada por el carro es incorrecta", 12, hora );
	}
	
	 @Test
	    public void testTiempoEnParqueadero( ){	    
	        setupEscenario1( );

	        assertEquals( "El tiempo de parqueo que calcula el carro es incorrecto", 1, carro.darTiempoEnParqueadero( 12 ) );
	        assertEquals( "El tiempo de parqueo que calcula el carro es incorrecto", 2, carro.darTiempoEnParqueadero( 13 ) );
	        assertEquals( "El tiempo de parqueo que calcula el carro es incorrecto", 4, carro.darTiempoEnParqueadero( 15 ) );
	        assertEquals( "El tiempo de parqueo que calcula el carro es incorrecto", 6, carro.darTiempoEnParqueadero( 17 ) );
	    }

	@Test
    public void testTienePlaca( )
    {
        setupEscenario1( );

        assertFalse( "El carro dice que tiene una placa diferente a la suya", carro.tienePlaca( "zzz123" ) );
    }
}
